#!/usr/bin/env node
/**
 * 茄子管家 v6.9.21 补丁脚本
 * 在服务器上执行：cd ~/qiezi-app && node apply-update.js
 * 原理：读取现有文件 → 精确字符串替换 → 写回
 * 安全：每个替换前检查是否已应用（幂等），自动备份
 */
const fs = require('fs');
const path = require('path');

const ROOT = process.cwd();
let changed = 0;
let skipped = 0;

function backup(file) {
  const bak = file + '.bak.' + Date.now();
  fs.copyFileSync(file, bak);
  console.log('  📦 备份:', bak);
}

function patch(file, oldStr, newStr, label) {
  const fp = path.join(ROOT, file);
  if (!fs.existsSync(fp)) { console.log('  ⚠️ 跳过(文件不存在):', file); skipped++; return; }
  let content = fs.readFileSync(fp, 'utf8');
  if (content.includes(newStr) || (oldStr && !content.includes(oldStr))) {
    console.log('  ⏭️ 跳过(已应用或找不到锚点):', label);
    skipped++;
    return;
  }
  if (!changed) backup(file);
  content = content.replace(oldStr, newStr);
  fs.writeFileSync(fp, content, 'utf8');
  console.log('  ✅ 已应用:', label);
  changed++;
}

function patchAll(file, oldStr, newStr, label) {
  const fp = path.join(ROOT, file);
  if (!fs.existsSync(fp)) { console.log('  ⚠️ 跳过(文件不存在):', file); skipped++; return; }
  let content = fs.readFileSync(fp, 'utf8');
  if (!content.includes(oldStr)) { console.log('  ⏭️ 跳过(找不到锚点):', label); skipped++; return; }
  if (!changed) backup(file);
  content = content.split(oldStr).join(newStr);
  fs.writeFileSync(fp, content, 'utf8');
  console.log('  ✅ 已应用:', label);
  changed++;
}

function insertAfter(file, anchor, code, label) {
  const fp = path.join(ROOT, file);
  if (!fs.existsSync(fp)) { console.log('  ⚠️ 跳过(文件不存在):', file); skipped++; return; }
  let content = fs.readFileSync(fp, 'utf8');
  if (content.includes(code.substring(0, 80))) { console.log('  ⏭️ 跳过(已应用):', label); skipped++; return; }
  const idx = content.indexOf(anchor);
  if (idx === -1) { console.log('  ⏭️ 跳过(找不到锚点):', label); skipped++; return; }
  if (!changed) backup(file);
  const end = idx + anchor.length;
  content = content.substring(0, end) + '\n' + code + content.substring(end);
  fs.writeFileSync(fp, content, 'utf8');
  console.log('  ✅ 已应用:', label);
  changed++;
}

function writeFile(file, content, label) {
  const fp = path.join(ROOT, file);
  if (fs.existsSync(fp) && fs.readFileSync(fp, 'utf8') === content) { console.log('  ⏭️ 跳过(已存在且一致):', label); skipped++; return; }
  fs.writeFileSync(fp, content, 'utf8');
  console.log('  ✅ 已写入:', label);
  changed++;
}

// ============================================================
// 1. server.js: ENG 对象末尾添加 weeklyReview / dataCompare / entropy
// ============================================================
console.log('\n🔧 [1/5] server.js: 添加 ENG 新方法...');

const ENG_NEW_METHODS = `
  // v6.9.21: 周回顾
  weeklyReview(hist) {
    const now = new Date();
    const start = new Date(now); start.setDate(now.getDate() - 7);
    const prevStart = new Date(start); prevStart.setDate(start.getDate() - 7);
    const startStr = start.toISOString().split('T')[0];
    const prevStartStr = prevStart.toISOString().split('T')[0];
    const todayStr = now.toISOString().split('T')[0];
    const thisWeek = hist.filter(x => { const d = (x.ts || '').split('T')[0]; return d >= startStr && d <= todayStr; });
    const lastWeek = hist.filter(x => { const d = (x.ts || '').split('T')[0]; return d >= prevStartStr && d < startStr; });
    const mods = {}; thisWeek.forEach(r => { mods[r.mid] = (mods[r.mid] || 0) + 1; });
    const prevMods = {}; lastWeek.forEach(r => { prevMods[r.mid] = (prevMods[r.mid] || 0) + 1; });
    const emoCur = thisWeek.filter(x => x.mid === 'emotion').map(x => parseFloat(x.data?.rating || x.data?.level || 0)).filter(v => v > 0);
    const emoPrev = lastWeek.filter(x => x.mid === 'emotion').map(x => parseFloat(x.data?.rating || x.data?.level || 0)).filter(v => v > 0);
    const sleepCur = thisWeek.filter(x => x.mid === 'sleep').map(x => parseFloat(x.data?.hours || x.data?.duration || 0)).filter(v => v > 0);
    const sleepPrev = lastWeek.filter(x => x.mid === 'sleep').map(x => parseFloat(x.data?.hours || x.data?.duration || 0)).filter(v => v > 0);
    const finCur = thisWeek.filter(x => x.mid === 'finance');
    const expCur = finCur.filter(x => x.data?.type === 'expense' || x.data?.type === '支出').reduce((s,x) => s + parseFloat(x.data?.amount || 0), 0);
    const incCur = finCur.filter(x => x.data?.type === 'income' || x.data?.type === '收入').reduce((s,x) => s + parseFloat(x.data?.amount || 0), 0);
    const finPrev = lastWeek.filter(x => x.mid === 'finance');
    const expPrev = finPrev.filter(x => x.data?.type === 'expense' || x.data?.type === '支出').reduce((s,x) => s + parseFloat(x.data?.amount || 0), 0);
    const incPrev = finPrev.filter(x => x.data?.type === 'income' || x.data?.type === '收入').reduce((s,x) => s + parseFloat(x.data?.amount || 0), 0);
    const moodAvg = emoCur.length ? emoCur.reduce((a,b)=>a+b,0)/emoCur.length : null;
    const moodPrevAvg = emoPrev.length ? emoPrev.reduce((a,b)=>a+b,0)/emoPrev.length : null;
    const sleepAvg = sleepCur.length ? sleepCur.reduce((a,b)=>a+b,0)/sleepCur.length : null;
    const sleepPrevAvg = sleepPrev.length ? sleepPrev.reduce((a,b)=>a+b,0)/sleepPrev.length : null;
    const changes = [];
    if (moodAvg !== null && moodPrevAvg !== null) { const d = moodAvg - moodPrevAvg; if (Math.abs(d) > 0.3) changes.push({ dim:'情绪', delta: d.toFixed(2), direction: d > 0 ? 'up' : 'down', note: d > 0 ? '情绪改善' : '情绪下滑' }); }
    if (sleepAvg !== null && sleepPrevAvg !== null) { const d = sleepAvg - sleepPrevAvg; if (Math.abs(d) > 0.3) changes.push({ dim:'睡眠', delta: d.toFixed(1) + 'h', direction: d > 0 ? 'up' : 'down', note: d > 0 ? '睡眠增加' : '睡眠减少' }); }
    if (expCur > 0 || expPrev > 0) { const d = expCur - expPrev; if (Math.abs(d) > 10) changes.push({ dim:'支出', delta: d.toFixed(0) + '元', direction: d < 0 ? 'up' : 'down', note: d < 0 ? '支出减少' : '支出增加' }); }
    const sp = [];
    sp.push('本周 ' + thisWeek.length + ' 条记录 · 覆盖 ' + Object.keys(mods).length + ' 维度');
    if (moodAvg !== null) sp.push('情绪 ' + moodAvg.toFixed(1) + '/5');
    if (sleepAvg !== null) sp.push('睡眠 ' + sleepAvg.toFixed(1) + 'h');
    if (incCur > 0 || expCur > 0) sp.push('收 ' + incCur.toFixed(0) + ' / 支 ' + expCur.toFixed(0));
    return {
      period: startStr + ' ~ ' + todayStr,
      totalRecords: thisWeek.length, prevRecords: lastWeek.length,
      moduleBreakdown: Object.entries(mods).sort((a,b) => b[1] - a[1]).map(([k,v]) => ({ module: k, count: v })),
      prevModuleBreakdown: Object.entries(prevMods).sort((a,b) => b[1] - a[1]).map(([k,v]) => ({ module: k, count: v })),
      stats: { moodAvg, moodPrevAvg, moodDelta: moodAvg !== null && moodPrevAvg !== null ? (moodAvg - moodPrevAvg).toFixed(2) : null, sleepAvg, sleepPrevAvg, sleepDelta: sleepAvg !== null && sleepPrevAvg !== null ? (sleepAvg - sleepPrevAvg).toFixed(2) : null, income: incCur, expense: expCur, net: incCur - expCur, prevIncome: incPrev, prevExpense: expPrev, prevNet: incPrev - expPrev },
      changes,
      summary: sp.join(' · '),
      highlights: thisWeek.length > lastWeek.length ? '记录增多——说明你在更有意识地观察自己。' : thisWeek.length < lastWeek.length ? '记录减少——是太忙了，还是动力下降？' : '记录持平——稳定是好事，但要警惕"稳定"变成"例行公事"。',
      generatedAt: new Date().toISOString()
    };
  },

  // v6.9.21: 数据对比
  dataCompare(hist) {
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    const weekStart = new Date(now); weekStart.setDate(now.getDate() - 6);
    const prevWeekStart = new Date(weekStart); prevWeekStart.setDate(weekStart.getDate() - 7);
    const weekStr = weekStart.toISOString().split('T')[0];
    const prevWeekStr = prevWeekStart.toISOString().split('T')[0];
    const monthStart = new Date(now); monthStart.setDate(1);
    const prevMonthStart = new Date(monthStart); prevMonthStart.setMonth(monthStart.getMonth() - 1);
    const monthStr = monthStart.toISOString().split('T')[0];
    const prevMonthStr = prevMonthStart.toISOString().split('T')[0];
    function aggRange(from, to) {
      const range = hist.filter(x => { const d = (x.ts || '').split('T')[0]; return d >= from && d <= to; });
      const mods = {}; range.forEach(r => { mods[r.mid] = (mods[r.mid] || 0) + 1; });
      const emo = range.filter(x => x.mid === 'emotion').map(x => parseFloat(x.data?.rating || x.data?.level || 0)).filter(v => v > 0);
      const slp = range.filter(x => x.mid === 'sleep').map(x => parseFloat(x.data?.hours || x.data?.duration || 0)).filter(v => v > 0);
      const fin = range.filter(x => x.mid === 'finance');
      const exp = fin.filter(x => x.data?.type === 'expense' || x.data?.type === '支出').reduce((s,x) => s + parseFloat(x.data?.amount || 0), 0);
      const inc = fin.filter(x => x.data?.type === 'income' || x.data?.type === '收入').reduce((s,x) => s + parseFloat(x.data?.amount || 0), 0);
      return { count: range.length, modules: Object.keys(mods).length, moodAvg: emo.length ? emo.reduce((a,b)=>a+b,0)/emo.length : null, moodCount: emo.length, sleepAvg: slp.length ? slp.reduce((a,b)=>a+b,0)/slp.length : null, sleepCount: slp.length, income: inc, expense: exp, net: inc - exp, moduleBreakdown: Object.entries(mods).sort((a,b) => b[1] - a[1]).map(([k,v]) => ({ module: k, count: v })) };
    }
    const thisWeek = aggRange(weekStr, today);
    const lastWeek = aggRange(prevWeekStr, weekStart.toISOString().split('T')[0]);
    const thisMonth = aggRange(monthStr, today);
    const lastMonth = aggRange(prevMonthStr, monthStr);
    function diffLine(cur, prev, label) {
      if (cur === null || prev === null || prev === 0) return null;
      const delta = cur - prev;
      const pct = prev !== 0 ? (delta / prev * 100).toFixed(1) : null;
      if (Math.abs(delta) < 0.01) return null;
      return { label, current: cur, previous: prev, delta, pct, direction: delta > 0 ? 'up' : 'down' };
    }
    const weekDiffs = [diffLine(thisWeek.moodAvg, lastWeek.moodAvg, '情绪均分'), diffLine(thisWeek.sleepAvg, lastWeek.sleepAvg, '睡眠时长'), diffLine(thisWeek.expense, lastWeek.expense, '支出'), diffLine(thisWeek.income, lastWeek.income, '收入'), diffLine(thisWeek.count, lastWeek.count, '记录数')].filter(Boolean);
    const monthDiffs = [diffLine(thisMonth.moodAvg, lastMonth.moodAvg, '情绪均分'), diffLine(thisMonth.sleepAvg, lastMonth.sleepAvg, '睡眠时长'), diffLine(thisMonth.expense, lastMonth.expense, '支出'), diffLine(thisMonth.income, lastMonth.income, '收入'), diffLine(thisMonth.count, lastMonth.count, '记录数')].filter(Boolean);
    return { week: { range: weekStr + ' ~ ' + today, prevRange: prevWeekStr + ' ~ ' + weekStart.toISOString().split('T')[0], current: thisWeek, previous: lastWeek, diffs: weekDiffs }, month: { range: monthStr + ' ~ ' + today, prevRange: prevMonthStr + ' ~ ' + monthStr, current: thisMonth, previous: lastMonth, diffs: monthDiffs }, generatedAt: new Date().toISOString() };
  },

  // v6.9.21: 熵分析（接受 hist 参数）
  entropy(hist) {
    const base = this.entropyMonitor();
    if (!hist || hist.length < 7) return base;
    const now = new Date();
    const weekAgo = new Date(now); weekAgo.setDate(now.getDate() - 7);
    const twoWeeksAgo = new Date(now); twoWeeksAgo.setDate(now.getDate() - 14);
    const ws = weekAgo.toISOString().split('T')[0];
    const tws = twoWeeksAgo.toISOString().split('T')[0];
    const thisWeek = hist.filter(x => (x.ts || '').split('T')[0] >= ws);
    const lastWeek = hist.filter(x => { const d = (x.ts || '').split('T')[0]; return d >= tws && d < ws; });
    const modCountCur = {}; const modCountPrev = {};
    thisWeek.forEach(r => { modCountCur[r.mid] = (modCountCur[r.mid] || 0) + 1; });
    lastWeek.forEach(r => { modCountPrev[r.mid] = (modCountPrev[r.mid] || 0) + 1; });
    const shrinking = [];
    Object.keys(modCountPrev).forEach(m => { const cur = modCountCur[m] || 0; const prev = modCountPrev[m]; if (prev >= 2 && cur < prev * 0.5) shrinking.push({ module: m, current: cur, previous: prev }); });
    return { ...base, trends: { shrinking, totalRecordsThisWeek: thisWeek.length, totalRecordsLastWeek: lastWeek.length, activeModulesThisWeek: Object.keys(modCountCur).length, activeModulesLastWeek: Object.keys(modCountPrev).length } };
  }
};`;

// 在 ENG 对象的 antiHumanNature 方法结束后插入
patch('server.js',
  "const score = 10 - detectedCount * 2;\n    return { text: lines.join('\\n'), score: Math.max(0, score), details };\n  }\n};",
  "const score = 10 - detectedCount * 2;\n    return { text: lines.join('\\n'), score: Math.max(0, score), details };\n  },\n" + ENG_NEW_METHODS,
  'ENG 新增 weeklyReview/dataCompare/entropy 方法'
);

// 船长宣言 → 人生宪法（全局替换）
console.log('\n🔧 [2/5] server.js: 船长宣言 → 人生宪法...');
patchAll('server.js', '船长宣言', '人生宪法', '文案替换: 船长宣言→人生宪法');
patchAll('server.js', '我的船长宣言', '我的人生宪法', '默认标题替换');
patchAll('server.js', '宣言太短', '宪法太短', 'manifesto 文案');
patchAll('server.js', '真宣言', '真宪法', 'manifesto 文案2');
patchAll('server.js', '签订宣言', '签订宪法', 'manifesto 按钮');
patchAll('server.js', '更新宣言', '更新宪法', 'manifesto 按钮2');

// ============================================================
// 3. frontend/app.js: 常用场景 + sparkline + dashboard 渲染 + 闪念合并
// ============================================================
console.log('\n🔧 [3/5] frontend/app.js: 前端修改...');

// 3a. openScene 加 incModuleUsage
patch('frontend/app.js',
  "function openScene(id){\n  curScene=id;\n  editId = null;\n  var s=SCENES.find",
  "function openScene(id){\n  curScene=id;\n  editId = null;\n  incModuleUsage(id);\n  var s=SCENES.find",
  'openScene 加使用计数'
);

// 3b. 添加 MODULE_USAGE 相关函数 + 重写 renderRecord
patch('frontend/app.js',
  "var MODULE_META = {\n  body:{name:'身体'",
  "var MODULE_USAGE_KEY = 'qiezi_module_usage_v1';\nfunction getModuleUsage(){try{return JSON.parse(localStorage.getItem(MODULE_USAGE_KEY)||'{}')}catch(e){return{}}}\nfunction incModuleUsage(mid){var u=getModuleUsage();u[mid]=(u[mid]||0)+1;u[mid+'_last']=Date.now();try{localStorage.setItem(MODULE_USAGE_KEY,JSON.stringify(u))}catch(e){}}\nfunction getTopModules(n){var u=getModuleUsage();var s={};Object.keys(u).forEach(function(k){if(k.endsWith('_last'))return;s[k]=u[k]});return Object.entries(s).sort(function(a,b){return b[1]-a[1]}).slice(0,n).map(function(x){return x[0]})}\n\nvar MODULE_META = {\n  body:{name:'身体'",
  'MODULE_USAGE 函数'
);

// 3c. 重写 renderRecord
patch('frontend/app.js',
  "function renderRecord(){\n  // 今日统计\n  renderRecToday();\n  // 分组渲染\n  Object.keys(RECORD_GROUPS).forEach(function(cat){",
  "function renderRecord(){\n  renderRecToday();\n  var topMods = getTopModules(6);\n  if (topMods.length > 0) {\n    var favEl = document.getElementById('recFavorites');\n    if (!favEl) {\n      favEl = document.createElement('div');\n      favEl.className = 'rec-group';\n      favEl.innerHTML = '<div class=\"rg-title\">⭐ 常用场景 <span class=\"rg-sub\">按使用频率自动排序</span></div><div class=\"scene-grid rec-grid\" id=\"recFavGrid\"></div>';\n      var recToday = document.getElementById('recToday');\n      if (recToday && recToday.parentNode) recToday.parentNode.insertBefore(favEl, recToday.nextSibling);\n    }\n    favEl.style.display = '';\n    var grid = document.getElementById('recFavGrid');\n    if (grid) grid.innerHTML = topMods.map(function(mid){ return renderSceneCard(mid, true); }).join('');\n  }\n  Object.keys(RECORD_GROUPS).forEach(function(cat){",
  'renderRecord 加常用场景'
);

// 3d. renderSceneCard 加 featured 参数
patch('frontend/app.js',
  "function renderSceneCard(mid){\n  var meta = MODULE_META[mid] || {name:mid, icon:'📄'};\n  var cnt = (dataCache[mid]||[]).length;\n  var todayCnt = countTodayRecords(mid);\n  var todayBadge = todayCnt > 0 ? '<div class=\"s-today\">'+todayCnt+'</div>' : '';\n  return '<div class=\"scene-card\" data-name=\"'+meta.name+'\" onclick=\"openScene(\\''+mid+'\\')\"><div class=\"s-ic\">'+meta.icon+'</div><div class=\"s-nm\">'+meta.name+'</div><div class=\"s-cnt\">'+cnt+'条</div>'+todayBadge+'</div>';\n}",
  "function renderSceneCard(mid, featured){\n  var meta = MODULE_META[mid] || {name:mid, icon:'📄'};\n  var cnt = (dataCache[mid]||[]).length;\n  var todayCnt = countTodayRecords(mid);\n  var todayBadge = todayCnt > 0 ? '<div class=\"s-today\">'+todayCnt+'</div>' : '';\n  var featBadge = featured ? '<div style=\"position:absolute;top:4px;right:4px;font-size:10px;color:var(--c-primary);\">⭐</div>' : '';\n  return '<div class=\"scene-card'+(featured?' scene-featured':'')+'\" data-name=\"'+meta.name+'\" onclick=\"openScene(\\''+mid+'\\')\" style=\"position:relative;\">'+featBadge+'<div class=\"s-ic\">'+meta.icon+'</div><div class=\"s-nm\">'+meta.name+'</div><div class=\"s-cnt\">'+cnt+'条</div>'+todayBadge+'</div>';\n}",
  'renderSceneCard 加 featured'
);

// 3e. renderOverview 重写 + sparkline
patch('frontend/app.js',
  "function renderOverview(){\n  var sleep = dataCache.sleep || [], emotion = dataCache.emotion || [];\n  var sl=0, em=0;\n  sleep.slice(-7).forEach(function(s){ sl += parseFloat(s.hours) || 0; });\n  emotion.slice(-7).forEach(function(e){ em += parseFloat(e.rating) || 0; });\n  document.getElementById('ovSleep').textContent = (sleep.length ? (sl/Math.min(7,sleep.length)).toFixed(1) : '-') + 'h';\n  document.getElementById('ovMood').textContent = (emotion.length ? (em/Math.min(7,emotion.length)).toFixed(1) : '-') + '/10';\n  document.getElementById('ovDays').textContent = Math.max(sleep.length, emotion.length, 1);\n}",
  "function renderOverview(){\n  var sleep = dataCache.sleep || [], emotion = dataCache.emotion || [];\n  var sl=0, em=0;\n  var sleepRecent = sleep.slice(-7);\n  var emotionRecent = emotion.slice(-7);\n  sleepRecent.forEach(function(s){ sl += parseFloat(s.hours) || 0; });\n  emotionRecent.forEach(function(e){ em += parseFloat(e.rating) || 0; });\n  var ovSleep = document.getElementById('ovSleep');\n  var ovMood = document.getElementById('ovMood');\n  var ovDays = document.getElementById('ovDays');\n  if (ovSleep) { var sa = sleep.length ? (sl/Math.min(7,sleep.length)).toFixed(1) : '-'; ovSleep.innerHTML = sa + 'h' + buildSparkline(sleepRecent, 'hours'); }\n  if (ovMood) { var ma = emotion.length ? (em/Math.min(7,emotion.length)).toFixed(1) : '-'; ovMood.innerHTML = ma + '/10' + buildSparkline(emotionRecent, 'rating'); }\n  if (ovDays) ovDays.textContent = Math.max(sleep.length, emotion.length, 1);\n  if (typeof collapseZeroData === 'function') collapseZeroData();\n}\nfunction collapseZeroData(){\n  if (!dataCache) return;\n  var allEmpty = true;\n  Object.keys(dataCache).forEach(function(k){ if (Array.isArray(dataCache[k]) && dataCache[k].length > 0) allEmpty = false; });\n  if (!allEmpty) return;\n  document.querySelectorAll('.tool-section').forEach(function(sec){\n    var items = sec.querySelectorAll('.tool-item');\n    var visibleCount = 0;\n    items.forEach(function(item){ var cntEl = item.querySelector('.t-cnt'); var cnt = cntEl ? cntEl.textContent : ''; if (cnt && cnt !== '0' && cnt !== '-' && cnt !== '未设' && cnt !== '未立' && cnt !== '新') visibleCount++; });\n    if (visibleCount === 0 && items.length > 3) sec.style.opacity = '0.4';\n  });\n}\nfunction buildSparkline(data, field){\n  if (!data || data.length < 2) return '';\n  var values = data.map(function(d){ return parseFloat(d[field]) || 0; });\n  if (values.every(function(v){ return v === 0; })) return '';\n  var w = 40, h = 14, pad = 2;\n  var min = Math.min.apply(null, values); var max = Math.max.apply(null, values); var range = max - min || 1;\n  var points = values.map(function(v, i){ var x = pad + (i / (values.length - 1)) * (w - 2*pad); var y = pad + (1 - (v - min) / range) * (h - 2*pad); return x.toFixed(1) + ',' + y.toFixed(1); }).join(' ');\n  var color = values[values.length-1] >= values[0] ? '#10B981' : '#EF4444';\n  return '<svg width=\"'+w+'\" height=\"'+h+'\" style=\"vertical-align:middle;margin-left:4px;\"><polyline points=\"'+points+'\" fill=\"none\" stroke=\"'+color+'\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></svg>';\n}",
  'renderOverview + sparkline + collapseZeroData'
);

// 3f. submitDailyAnswer 重写（合并闪念）
patch('frontend/app.js',
  "async function submitDailyAnswer() {\n  var inp = document.getElementById('dailyQuestionInput');\n  if (!inp) return;\n  var ans = inp.value.trim();\n  if (!ans) { alert('请先写下你的回答'); return; }\n  try {\n    var today = new Date().toISOString().split('T')[0];\n    var r = await fetch('/api/daily-question/answer', {\n      method: 'POST',\n      headers: { 'Content-Type': 'application/json' },\n      body: JSON.stringify({ answer: ans, date: today })\n    });\n    var d = await r.json();\n    if (d.success) {\n      alert('✅ 回答已保存！深度评分：' + d.depthScore + '/5');\n      loadDailyQuestion();\n      if (typeof renderOverview === 'function') renderOverview();\n    } else {\n      alert('保存失败：' + d.message);\n    }\n  } catch(e) { alert('网络错误，请重试'); }\n}",
  "async function submitDailyAnswer() {\n  var inp = document.getElementById('dailyQuestionInput');\n  if (!inp) return;\n  var ans = inp.value.trim();\n  if (!ans) { alert('请先写下你的想法'); return; }\n  var today = new Date().toISOString().split('T')[0];\n  var qEl = document.getElementById('dailyQuestionText');\n  var hasQuestion = qEl && qEl.textContent && qEl.textContent.trim().length > 0;\n  var isQuickNote = !hasQuestion || ans.length < 5 || !hasQuestion;\n  try {\n    if (isQuickNote) {\n      var r2 = await fetch('/api/quick-note', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content: ans }) });\n      var d2 = await r2.json();\n      if (d2.success) {\n        var fb = document.getElementById('quickNoteFeedback');\n        if (fb) fb.innerHTML = '✅ 已自动归类到 <b>'+ (d2.module || '闪念') + '</b>';\n        inp.value = '';\n        setTimeout(function(){ if(fb) fb.innerHTML = ''; }, 3000);\n      } else { alert('保存失败：' + d2.message); }\n    } else {\n      var r = await fetch('/api/daily-question/answer', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ answer: ans, date: today }) });\n      var d = await r.json();\n      if (d.success) {\n        alert('✅ 回答已保存！深度评分：' + d.depthScore + '/5');\n        loadDailyQuestion();\n        if (typeof renderOverview === 'function') renderOverview();\n      } else { alert('保存失败：' + d.message); }\n    }\n  } catch(e) { alert('网络错误，请重试'); }\n}",
  'submitDailyAnswer 合并闪念'
);

// 3g. dashboard 添加 weeklyReview/dataCompare 渲染
patch('frontend/app.js',
  "  // v6.5.9 周对周/月对月数据对比图\n  html += renderTrendComparison();",
  "  // v6.9.21: weeklyReview + dataCompare 渲染\n  if(s.weeklyReview){\n    var wr = s.weeklyReview;\n    html += '<div style=\"background:var(--c-surface);border-radius:14px;padding:12px 16px;margin-bottom:12px;\">';\n    html += '<div style=\"display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;\"><span style=\"font-size:12px;font-weight:600;color:var(--c-fg-2);\">📅 周回顾</span><span style=\"font-size:11px;color:var(--c-fg-3);\">'+wr.period+'</span></div>';\n    if(wr.summary) html += '<div style=\"font-size:12px;color:var(--c-fg);line-height:1.5;margin-bottom:6px;\">'+escapeHtml(wr.summary)+'</div>';\n    if(wr.changes && wr.changes.length){ wr.changes.forEach(function(c){ var ar = c.direction === 'up' ? '↑' : '↓'; var co = c.direction === 'up' ? 'var(--c-success)' : 'var(--c-danger)'; html += '<div style=\"font-size:11px;color:var(--c-fg-2);padding:2px 0;\"><span style=\"color:'+co+';\">'+ar+'</span> '+escapeHtml(c.dim)+' '+escapeHtml(c.delta)+' <span style=\"color:var(--c-fg-3);\">'+escapeHtml(c.note||'')+'</span></div>'; }); }\n    if(wr.highlights) html += '<div style=\"font-size:11px;color:var(--c-fg-3);margin-top:4px;font-style:italic;\">'+escapeHtml(wr.highlights)+'</div>';\n    html += '</div>';\n  }\n  if(s.dataCompare){\n    var dc = s.dataCompare;\n    if(dc.week && dc.week.diffs && dc.week.diffs.length){\n      html += '<div style=\"background:var(--c-surface);border-radius:14px;padding:12px 16px;margin-bottom:12px;\">';\n      html += '<div style=\"font-size:12px;font-weight:600;color:var(--c-fg-2);margin-bottom:6px;\">📊 周对比</div>';\n      dc.week.diffs.forEach(function(d){ var ar = d.direction === 'up' ? '↑' : '↓'; var co = d.direction === 'up' ? 'var(--c-success)' : 'var(--c-danger)'; html += '<div style=\"display:flex;justify-content:space-between;font-size:11px;padding:2px 0;\"><span style=\"color:var(--c-fg-2);\">'+escapeHtml(d.label)+'</span><span><span style=\"color:'+co+';\">'+ar+'</span> '+escapeHtml(d.current)+' <span style=\"color:var(--c-fg-3);\">('+(d.pct?d.pct+'%':'')+')</span></span></div>'; });\n      html += '</div>';\n    }\n    if(dc.month && dc.month.diffs && dc.month.diffs.length){\n      html += '<div style=\"background:var(--c-surface);border-radius:14px;padding:12px 16px;margin-bottom:12px;\">';\n      html += '<div style=\"font-size:12px;font-weight:600;color:var(--c-fg-2);margin-bottom:6px;\">📊 月对比</div>';\n      dc.month.diffs.forEach(function(d){ var ar = d.direction === 'up' ? '↑' : '↓'; var co = d.direction === 'up' ? 'var(--c-success)' : 'var(--c-danger)'; html += '<div style=\"display:flex;justify-content:space-between;font-size:11px;padding:2px 0;\"><span style=\"color:var(--c-fg-2);\">'+escapeHtml(d.label)+'</span><span><span style=\"color:'+co+';\">'+ar+'</span> '+escapeHtml(d.current)+' <span style=\"color:var(--c-fg-3);\">('+(d.pct?d.pct+'%':'')+')</span></span></div>'; });\n      html += '</div>';\n    }\n  }\n  html += renderTrendComparison();",
  'dashboard weeklyReview/dataCompare 渲染'
);

// 3h. openManifesto 文案
patchAll('frontend/app.js', '船长宣言', '人生宪法', 'app.js manifesto 文案');

// ============================================================
// 4. frontend/index.html: 瞭望重组 + 人生宪法 + 闪念合并
// ============================================================
console.log('\n🔧 [4/5] frontend/index.html: HTML 修改...');

// 4a. 船长宣言 → 人生宪法
patchAll('frontend/index.html', '船长宣言', '人生宪法', 'index.html manifesto 标签');

// 4b. 今日之问 + 闪念合并
patch('frontend/index.html',
  '    <span style="font-size:11px;color:var(--c-fg-2);">💭 今日之问</span>',
  '    <span style="font-size:11px;color:var(--c-fg-2);">💭 今日之问 · 闪念</span>',
  '今日之问标题合并闪念'
);
patch('frontend/index.html',
  '  <div id="dailyQuestionText" style="font-size:15px;color:var(--c-fg);font-weight:500;margin-bottom:8px;">加载中...</div>',
  '  <div id="dailyQuestionText" style="font-size:15px;color:var(--c-fg);font-weight:500;margin-bottom:8px;"></div>',
  '今日之问文本清空加载文字'
);
patch('frontend/index.html',
  '    <input type="text" id="dailyQuestionInput" placeholder="写下你的回答..."',
  '    <input type="text" id="dailyQuestionInput" placeholder="写下你的想法——回答今日之问，或随便记一笔..."',
  '输入框 placeholder 合并'
);
patch('frontend/index.html',
  "cursor:pointer;\">回答</button>",
  "cursor:pointer;\">记录</button>",
  '按钮文字: 回答→记录'
);

// 4c. 闪念区域添加 feedback div（如果不存在）
patch('frontend/index.html',
  '  <div id="dailyAnswerDisplay" style="margin-top:8px;font-size:13px;color:var(--c-fg-2);display:none;"></div>\n</div>\n\n<!-- Section: 概览 -->',
  '  <div id="dailyAnswerDisplay" style="margin-top:8px;font-size:13px;color:var(--c-fg-2);display:none;"></div>\n  <div id="quickNoteFeedback" style="margin-top:6px;font-size:12px;color:var(--c-fg-2);"></div>\n</div>\n\n<!-- Section: 概览 -->',
  '添加 quickNoteFeedback div'
);

// 4d. 删除独立的闪念区域
patch('frontend/index.html',
  '<!-- Section: 闪念 -->\n<div class="section-label">💭 闪念</div>\n<!-- ====== 闪念笔记 ====== -->\n<div style="background:var(--c-surface);border-radius:12px;padding:12px 14px;margin-bottom:16px;">\n  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">\n    <span style="font-size:13px;font-weight:600;color:var(--c-fg);">💭 闪念笔记</span>\n    <span style="font-size:10px;color:var(--c-fg-3);cursor:pointer;" onclick="showQuickNotes()">查看全部</span>\n  </div>\n  <div style="display:flex;gap:8px;">\n    <input type="text" id="quickNoteInput" placeholder="随便记一下... 系统会自动归类" style="flex:1;padding:8px 12px;border-radius:8px;background:var(--c-input-bg);color:var(--c-fg);font-size:14px;outline:none;border:1px solid var(--c-input-border);">\n    <button onclick="submitQuickNote()" style="background:linear-gradient(135deg,var(--c-primary),var(--c-primary-2));border:none;border-radius:8px;padding:8px 16px;color:#fff;font-size:14px;font-weight:600;cursor:pointer;">记</button>\n  </div>\n  <div id="quickNoteFeedback" style="margin-top:6px;font-size:12px;color:var(--c-fg-2);"></div>\n</div>\n</div><!-- end homeContent -->',
  '</div><!-- end homeContent -->',
  '删除独立闪念区域'
);

// ============================================================
// 5. ecosystem.config.js
// ============================================================
console.log('\n🔧 [5/5] ecosystem.config.js: 检查/创建...');

writeFile('ecosystem.config.js', `module.exports = {
  apps: [{
    name: 'eggplant',
    script: 'server.js',
    cwd: __dirname,
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    max_restarts: 10,
    restart_delay: 3000,
    max_memory_restart: '512M',
    env: {
      NODE_ENV: 'production',
      PORT: 3000,
      LOG_LEVEL: 'info',
      LOG_PRETTY: '0'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss',
    merge_logs: true,
    kill_timeout: 5000,
    listen_timeout: 8000
  }]
};
`, 'ecosystem.config.js');

// ============================================================
// 完成
// ============================================================
console.log('\n========================================');
console.log('✅ 补丁应用完成！');
console.log('   已修改: ' + changed + ' 项');
console.log('   已跳过: ' + skipped + ' 项');
console.log('========================================');
if (changed > 0) {
  console.log('\n📌 下一步：');
  console.log('  pm2 restart eggplant');
  console.log('  curl -s http://localhost:3000/api/health');
} else {
  console.log('\n📌 所有补丁均已应用，无需重启');
}
